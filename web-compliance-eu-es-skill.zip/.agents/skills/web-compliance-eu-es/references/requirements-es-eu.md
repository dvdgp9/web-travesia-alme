# Requisitos prácticos UE / España para la skill

## 1. Cookies y tecnologías similares
La skill debe asumir como regla operativa:
- consentimiento previo para cookies no necesarias,
- información clara y completa,
- rechazo visible y al mismo nivel que aceptación,
- retirada del consentimiento tan fácil como otorgarlo,
- no interpretar seguir navegando como consentimiento,
- no usar opciones premarcadas,
- no usar muros de cookies salvo estrategia muy documentada y alternativa equivalente.

## 2. Aviso legal
Debe contemplar datos de identificación del prestador:
- nombre o razón social,
- domicilio,
- email u otro medio directo,
- NIF/CIF si aplica,
- datos registrales si aplica,
- información de precios e impuestos cuando corresponda.

## 3. Política de privacidad
Debe alinearse con la realidad del tratamiento e incluir, como mínimo:
- responsable,
- contacto DPO si existe,
- finalidades,
- base jurídica,
- destinatarios,
- transferencias internacionales,
- conservación,
- derechos,
- autoridad de control.

## 4. Formularios y marketing
La skill debe distinguir:
- contacto / atención de solicitudes,
- newsletter / promociones,
- empleo / candidaturas,
- registros / cuentas,
- checkout / contratación.

No debe mezclar el consentimiento comercial con otras finalidades cuando deban separarse.

## 5. E-commerce
Si la web vende, deben contemplarse:
- información precontractual,
- condiciones generales accesibles y descargables,
- confirmación de aceptación,
- información de desistimiento cuando aplique.

## 6. Lo que la skill nunca debe inventar
- datos societarios,
- proveedores,
- transferencias,
- plazos de conservación,
- DPO,
- bases jurídicas,
- categorías de datos especiales,
- tratamientos de menores.
