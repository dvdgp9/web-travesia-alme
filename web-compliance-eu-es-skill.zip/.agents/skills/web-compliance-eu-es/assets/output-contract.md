# Output contract

La skill debe terminar cada ejecución con este formato:

## Changed files
- lista de archivos creados o modificados

## Technical compliance status
- scripts bloqueados antes del consentimiento
- scripts todavía pendientes
- estado del acceso persistente a preferencias

## Legal data gaps
- `TODO-LEGAL:` pendientes
- contradicciones entre código y textos

## Manual launch checks
- navegación inicial sin cookies no necesarias
- flujo de aceptar
- flujo de rechazar
- reabrir preferencias
- coherencia de políticas
- revisión de formularios
