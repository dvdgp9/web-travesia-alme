#!/usr/bin/env python3
from __future__ import annotations

import json
import os
import re
import sys
from pathlib import Path

PATTERNS = {
    "google_tag_manager": [r"googletagmanager\.com", r"GTM-[A-Z0-9]+"],
    "google_analytics": [r"google-analytics\.com", r"gtag\(", r"GA_MEASUREMENT_ID", r"G-[A-Z0-9]+"],
    "meta_pixel": [r"connect\.facebook\.net", r"fbq\("],
    "hotjar": [r"hotjar", r"static\.hotjar\.com"],
    "microsoft_clarity": [r"clarity\.ms", r"clarity\("],
    "youtube": [r"youtube\.com/embed", r"youtu\.be", r"youtube-nocookie\.com"],
    "google_maps": [r"google\.com/maps", r"maps\.googleapis\.com", r"google.maps"],
    "vimeo": [r"player\.vimeo\.com"],
    "recaptcha": [r"google\.com/recaptcha", r"g-recaptcha", r"grecaptcha"],
    "hubspot": [r"hs-scripts\.com", r"hubspot"],
    "linkedin_insight": [r"snap\.licdn\.com", r"_linkedin_data_partner_id"],
    "tiktok_pixel": [r"analytics\.tiktok\.com", r"ttq\."],
    "cookiebot": [r"cookiebot", r"Cookiebot"],
    "onetrust": [r"OneTrust", r"Optanon"],
    "didomi": [r"didomi"],
}

FORM_HINTS = [
    r"<form\b",
    r"type=['\"]email['\"]",
    r"name=['\"]email['\"]",
    r"newsletter",
    r"contacto",
    r"privacy",
    r"privacidad",
    r"consent",
]

LEGAL_HINTS = {
    "privacy_policy": [r"privacy", r"privacidad", r"politica-de-privacidad", r"privacy-policy"],
    "cookie_policy": [r"cookies", r"politica-de-cookies", r"cookie-policy"],
    "legal_notice": [r"aviso-legal", r"legal-notice", r"imprint"],
    "terms": [r"terminos", r"terms", r"condiciones", r"terms-and-conditions"],
}

TEXT_EXTS = {".html", ".htm", ".js", ".jsx", ".ts", ".tsx", ".vue", ".php", ".css"}
EXCLUDED_DIRS = {".git", "node_modules", "dist", "build", ".next", ".nuxt", "vendor", ".agents"}
EXCLUDED_FILENAMES = {"compliance-manifest.json", "discovery-report.json", "AGENTS.md", ".DS_Store"}

def safe_read(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return ""

def main() -> int:
    root = Path(sys.argv[1] if len(sys.argv) > 1 else ".").resolve()
    if not root.exists():
        print(json.dumps({"error": f"Path not found: {root}"}))
        return 1

    findings = {
        "root": str(root),
        "services_detected": [],
        "service_hits": {},
        "form_candidates": [],
        "legal_page_candidates": {k: [] for k in LEGAL_HINTS},
        "cookie_ui_candidates": [],
        "files_scanned": 0,
    }

    service_hits = {k: [] for k in PATTERNS}

    if root.is_file():
        candidate_paths = [root]
    else:
        candidate_paths = root.rglob("*")

    for path in candidate_paths:
        if not path.is_file():
            continue
        if path.suffix.lower() not in TEXT_EXTS:
            continue
        if path.name in EXCLUDED_FILENAMES:
            continue
        if any(part in EXCLUDED_DIRS for part in path.parts):
            continue

        findings["files_scanned"] += 1
        text = safe_read(path)
        lower = text.lower()

        for service, patterns in PATTERNS.items():
            for pat in patterns:
                if re.search(pat, text):
                    service_hits[service].append(str(path))
                    break

        if any(re.search(p, text, re.IGNORECASE) for p in FORM_HINTS):
            findings["form_candidates"].append(str(path))

        for key, pats in LEGAL_HINTS.items():
            if any(re.search(p, str(path), re.IGNORECASE) or re.search(p, text, re.IGNORECASE) for p in pats):
                findings["legal_page_candidates"][key].append(str(path))

        if re.search(r"cookie|cookies|consent|consentimiento|optanon|didomi|cookiebot", text, re.IGNORECASE):
            findings["cookie_ui_candidates"].append(str(path))

    findings["services_detected"] = [k for k, v in service_hits.items() if v]
    findings["service_hits"] = {k: v for k, v in service_hits.items() if v}
    findings["form_candidates"] = sorted(set(findings["form_candidates"]))[:100]
    findings["cookie_ui_candidates"] = sorted(set(findings["cookie_ui_candidates"]))[:100]
    findings["legal_page_candidates"] = {k: sorted(set(v))[:50] for k, v in findings["legal_page_candidates"].items()}

    print(json.dumps(findings, ensure_ascii=False, indent=2))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
