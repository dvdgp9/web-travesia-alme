---
name: web-compliance-eu-es
description: Use this skill when building, editing or auditing websites that need EU/Spain privacy and cookie compliance. Trigger for cookie banners, consent management, legal pages, forms, newsletter signup, analytics, embeds, pixels, e-commerce checkout, or privacy-related web flows. Do not use for purely visual work with no data collection or tracking implications.
---

# Purpose

This skill helps Codex implement a **compliance-by-default** web workflow for EU websites, with Spain as the default legal-operational profile.

This skill is **not a legal guarantee**. It is a structured implementation workflow that:
1. discovers tracking/data collection behavior,
2. requires a structured manifest for facts the model must not invent,
3. implements safer defaults,
4. produces an explicit gap report for human review.

# Core principles

- Never claim the site is "fully compliant", "certified", or "legally guaranteed".
- Never invent:
  - company identity data
  - registry data
  - tax/VAT ID
  - DPO details
  - processors/subprocessors
  - international transfer details
  - retention periods
  - lawful bases
  - age thresholds beyond what the manifest provides
- If facts are missing, stop generating final legal text and leave `TODO-LEGAL:` markers.
- Prefer technical behavior that is safer by default:
  - block non-essential scripts before consent,
  - provide accept / reject / configure in first layer,
  - allow granular preferences by purpose,
  - provide a persistent way to reopen preferences.

# Inputs you should look for

## Mandatory
- `compliance-manifest.json` in repo root, or a user-provided equivalent.

## Helpful
- Output from:
  - `scripts/discover_web_compliance.py`
- Existing files:
  - legal pages
  - analytics config
  - tag manager config
  - forms
  - cookie banner components
  - consent hooks / tracking utilities

# Workflow

## 1. Discover project behavior
Before changing code, inspect the project.

If available, run:
```bash
python .agents/skills/web-compliance-eu-es/scripts/discover_web_compliance.py .
```

Review:
- detected tracking services
- forms and data capture points
- embedded third-party content
- current legal pages
- current cookie UI and preference mechanisms

If the script cannot run, perform an equivalent manual scan of the repo.

## 2. Validate the manifest
Find `compliance-manifest.json`.

If missing:
- tell the user exactly that the file is missing,
- create it from the example template if asked,
- do not invent legal facts.

If present, validate it if possible:
```bash
python .agents/skills/web-compliance-eu-es/scripts/validate_manifest.py ./compliance-manifest.json
```

If validation fails:
- summarize the missing/invalid fields,
- do not finalize legal copy until the manifest is fixed.

## 3. Build a compliance plan
Split work into these buckets:

### A. Consent and script loading
- identify non-essential cookies/scripts
- prevent them from loading before consent
- preserve strictly necessary scripts only
- add accept/reject/configure controls
- add persistent "cookie settings" access

### B. Public legal content
- privacy policy
- cookie policy
- legal notice / imprint
- e-commerce additions if relevant
- marketing and newsletter disclosures

### C. Data capture surfaces
- contact forms
- quote/request forms
- job application forms
- login/register/account areas
- checkout flows
- support/chat widgets
- embedded third-party services

## 4. Implement safer defaults
When coding:
- gate all non-essential tags behind consent state
- separate purposes at least by:
  - necessary
  - analytics
  - personalization
  - advertising
  - external media if applicable
- make reject as easy as accept
- avoid pre-ticked boxes
- avoid patterns that imply consent from continued browsing
- avoid cookie walls unless the manifest explicitly documents a lawful strategy and a genuine equivalent alternative

## 5. Generate legal pages only from facts
Use the manifest as the source of truth.

If a required field is missing, insert:
- `TODO-LEGAL: ...`

Keep legal text factual, plain, and aligned with the actual implementation.

Never list processors or cookies that are not actually present.
Never omit processors or cookies that are actually present.

## 6. Produce a gap report
At the end, always report:
- files created or modified
- tracking services detected
- remaining legal TODOs
- manual checks before launch
- whether manifest data was complete or partial

# Output contract

When asked to implement or audit, end with a concise report using these sections:

## Changed files
- list files

## Technical compliance status
- what is blocked pre-consent
- what still needs work

## Legal data gaps
- each `TODO-LEGAL`

## Manual launch checks
- browser test pre-consent
- reject flow
- reopen preferences
- policy-text consistency
- form disclosures
- consent log approach if applicable

# Implementation guidelines

## Cookie/UI behavior
Required UX expectations:
- first layer must surface:
  - accept
  - reject
  - configure
- reject must not be hidden behind more clicks than accept
- cookie preferences must be reachable later from footer or persistent settings entry
- saving no optional categories must equal rejecting all optional cookies

## Script loading
Treat these as non-essential unless the manifest explicitly justifies otherwise:
- Google Analytics
- Google Tag Manager when used for marketing/analytics tags
- Meta Pixel
- Hotjar / Clarity / session replay
- YouTube embeds with tracking
- Google Maps embeds
- Vimeo embeds
- HubSpot trackers
- ad network tags
- A/B testing tags that store/read identifiers
- social media widgets

For external media, prefer click-to-load placeholders until the relevant purpose is accepted.

## Forms
For each form:
- identify controller
- identify purpose
- identify lawful basis from manifest
- identify recipients/processors if any
- identify retention or criteria
- identify user rights channel
- separate newsletter/marketing consent from the main form if needed

## E-commerce
If `site_features.ecommerce = true`, ensure the project includes:
- pre-contract information
- terms visibility/downloadability
- order flow clarity
- confirmation mechanics
- withdrawal/right-of-withdrawal placeholders if consumer sales apply
- tax/price presentation alignment based on manifest

# When to refuse completion
Do not mark the job complete if any of these remain unresolved:
- non-essential scripts still load before consent
- no visible reject path
- policies contain invented legal facts
- the manifest is absent and the user expects production-ready legal text
- processors in policy do not match real integrations

# Suggested commands

```bash
python .agents/skills/web-compliance-eu-es/scripts/discover_web_compliance.py .
python .agents/skills/web-compliance-eu-es/scripts/validate_manifest.py ./compliance-manifest.json
```

# Deliverable style
- concise
- explicit
- no legal overclaiming
- every missing fact becomes a visible TODO
