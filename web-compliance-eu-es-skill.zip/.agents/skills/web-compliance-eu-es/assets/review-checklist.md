# Checklist de revisión manual

## Cookies y consentimiento
- [ ] La web no instala cookies no necesarias en la primera carga.
- [ ] Existe botón visible para Aceptar.
- [ ] Existe botón visible para Rechazar.
- [ ] Existe acceso a Configurar.
- [ ] Rechazar no requiere más pasos que aceptar.
- [ ] No hay casillas premarcadas a favor de aceptar.
- [ ] Continuar navegando no se interpreta como consentimiento.
- [ ] Hay acceso permanente para reabrir preferencias.

## Scripts y terceros
- [ ] Los terceros del código coinciden con la política de cookies.
- [ ] Los terceros del código coinciden con la política de privacidad.
- [ ] Los embeds externos están bloqueados o en click-to-load si procede.
- [ ] GTM/GA/Meta/Hotjar/etc. respetan el estado de consentimiento.

## Páginas legales
- [ ] Aviso legal publicado y accesible.
- [ ] Política de privacidad publicada y accesible.
- [ ] Política de cookies publicada y accesible.
- [ ] Términos/condiciones si hay contratación.
- [ ] Derecho de desistimiento / devoluciones si aplica.

## Formularios
- [ ] Cada formulario informa de finalidad.
- [ ] Cada formulario informa de base jurídica.
- [ ] Cada formulario informa de destinatarios o categorías.
- [ ] Cada formulario informa de conservación o criterio.
- [ ] Cada formulario informa de derechos y canal de ejercicio.
- [ ] El consentimiento de newsletter está separado si hace falta.

## Riesgos frecuentes
- [ ] Textos legales genéricos que no reflejan la realidad.
- [ ] Scripts insertados desde plugins no controlados.
- [ ] Páginas legales sin datos registrales reales.
- [ ] Transferencias internacionales sin documentar.
