#!/usr/bin/env python3
from __future__ import annotations

import json
import sys
from pathlib import Path

REQUIRED_TOP = ["site", "controller", "site_features", "tracking", "forms", "legal"]
REQUIRED_SITE = ["name", "url", "languages", "target_regions"]
REQUIRED_CONTROLLER = ["legal_name", "email", "country"]
REQUIRED_FEATURES = ["ecommerce", "accounts", "newsletter", "jobs", "minors_targeted"]
REQUIRED_TRACKING = ["services", "consent_categories"]
REQUIRED_LEGAL = ["privacy_policy", "cookie_policy", "legal_notice"]

def err(msg: str) -> str:
    return f"ERROR: {msg}"

def main() -> int:
    if len(sys.argv) < 2:
        print(err("Usage: validate_manifest.py <path-to-compliance-manifest.json>"))
        return 1

    path = Path(sys.argv[1])
    if not path.exists():
        print(err(f"File not found: {path}"))
        return 1

    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception as e:
        print(err(f"Invalid JSON: {e}"))
        return 1

    errors = []

    for key in REQUIRED_TOP:
        if key not in data:
            errors.append(f"Missing top-level key: {key}")

    for key in REQUIRED_SITE:
        if key not in data.get("site", {}):
            errors.append(f"Missing site.{key}")

    for key in REQUIRED_CONTROLLER:
        if key not in data.get("controller", {}):
            errors.append(f"Missing controller.{key}")

    for key in REQUIRED_FEATURES:
        if key not in data.get("site_features", {}):
            errors.append(f"Missing site_features.{key}")

    for key in REQUIRED_TRACKING:
        if key not in data.get("tracking", {}):
            errors.append(f"Missing tracking.{key}")

    for key in REQUIRED_LEGAL:
        if key not in data.get("legal", {}):
            errors.append(f"Missing legal.{key}")

    if not isinstance(data.get("forms", []), list):
        errors.append("forms must be an array")

    for i, form in enumerate(data.get("forms", [])):
        for key in ("id", "purpose", "lawful_basis"):
            if key not in form:
                errors.append(f"forms[{i}] missing {key}")

    if errors:
        print("Manifest validation failed:\n")
        for e in errors:
            print(f"- {e}")
        return 1

    print("Manifest validation OK")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
